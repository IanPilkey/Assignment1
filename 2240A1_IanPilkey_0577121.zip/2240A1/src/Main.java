//This program takes the Nth number of a fibonacci series from the user the displays
//the series and how long it took to execute

import java.util.Scanner;

public class Main {
	
	private static Scanner z;

	public static void main(String[] args) {
		
		int userN;
		z = new Scanner(System.in);
		
		//Explains code to the user and then asks for a number
		System.out.println("Welcome User.");
		System.out.println("This program will create a fibonacci series up to the number entered by the user.");
		System.out.println("Please enter a number.");
		userN = z.nextInt();
		z.nextLine();
		
		
		
		//Runs the recursion function
		System.out.println("Recursion");
		//Starts the timer
		long startTime1 = System.nanoTime();
		for (int i=0;i<userN;i++) {
			            System.out.print(fiboSeriesRec(i) + " ");
			        }
		//Ends the timer
        long endTime1 = System.nanoTime();
        //Finds out the time
        long timeElapsed1 = endTime1-startTime1;
        System.out.println("");
        //Displays the time to do the fibonacci number
        System.out.println("Elapsed time in nanoseconds is: " + timeElapsed1);
        //Converting time from nanoseconds to milliseconds
        System.out.println("Elapsed time in milliseconds is: " + timeElapsed1/1000000);

        
        System.out.println("");
        
        
        //Runs the iterative function
        System.out.println("Iterative");
		//Starts the timer
		long startTime2 = System.nanoTime();
		fiboSeriesIte(userN);
		//Ends the timer
        long endTime2 = System.nanoTime();
        //Finds out the time
        long timeElapsed2 = endTime2-startTime2;
        System.out.println("");
        //Displays the time to do the fibonacci number
        System.out.println("Elapsed time in nanoseconds is: " + timeElapsed2);
        //Converting time from nanoseconds to milliseconds
        System.out.println("Elapsed time in milliseconds is: " + timeElapsed2/1000000);

	}
	
	//https://examples.javacodegeeks.com/core-java/java-recursion-example/
	//Recursion function
	public static long fiboSeriesRec(long n) {
		if (n<0){
			System.out.println("Can't accept negative arguments");	
		}
		return (n < 2) ? n : fiboSeriesRec(n-1) + fiboSeriesRec(n-2);
	}
	
	//Iterative function
	public static void fiboSeriesIte(int userN){
		long n1 = 0;
		long n2 = 1;
		long n3;
		
		System.out.print(n1 + ", " + n2);
		for(int i=2; i<userN; i++){
			n3 = n1 + n2;
			System.out.print(", " + n3);
			n1 = n2;
			n2 = n3;
		}
	}
}
